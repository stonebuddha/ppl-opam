#ifndef CAFFE2_PROTO_TORCH_PB_H_
#define CAFFE2_PROTO_TORCH_PB_H_

#include <caffe2/core/common.h>
#include <caffe2/proto/caffe2_pb.h>
#include <caffe2/proto/torch.pb.h>

#endif // CAFFE2_PROTO_TORCH_PB_H_
