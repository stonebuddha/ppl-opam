#pragma once
#include "c10/util/numa.h"
#include "caffe2/core/common.h"
